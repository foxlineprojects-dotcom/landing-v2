import React from "react";
import Logo from "../assets/Foxline_logo.png";
import DarkModeToggle from "./components/DarkModeToggle";
import TestimonialsCarousel from "./components/TestimonialsCarousel";
import FaqSection from "./components/FaqSection";
import About from "./components/About";
import Image from "next/image";
import BlogPreviewWrapper from "./components/BlogPreviewWrapper";
import FreeAnalysisForm from "./components/FreeAnalysisForm";

export default function FoxlineLanding() {
  return (
    <div className="min-h-screen pb-20 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-gray-900 dark:to-gray-950">
      <header className="flex justify-between items-center p-6 max-w-5xl mx-auto">
        {/* <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
          Foxline
        </h1> */}

        <div>
          <Image src={Logo} alt="" className="w-[120px]" />
        </div>
        <DarkModeToggle />
      </header>

      <FreeAnalysisForm />

      {/* Testimonials Carousel */}
      <section className="w-full max-w-4xl mx-auto mt-12 px-4">
        <h2 className="text-2xl font-semibold mb-6 text-center text-slate-900 dark:text-white">
          Real Stories from Foxline Users
        </h2>
        <TestimonialsCarousel />
      </section>

      <About />
      <BlogPreviewWrapper />
      <FaqSection />
    </div>
  );
}
