"use client";

import { useState } from "react";
import { CheckCircle } from "lucide-react";

export default function FreeAnalysisForm() {
  const [formData, setFormData] = useState({
    firstName: "",
    email: "",
    file: null,
  });
  const [submitted, setSubmitted] = useState(false);
  const [fileName, setFileName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, file });
      setFileName(file.name);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!formData.firstName || !formData.email || !formData.file) {
      return setError("Please fill out all fields and upload your contract.");
    }

    setLoading(true);
    try {
      const form = new FormData();
      form.append("firstName", formData.firstName);
      form.append("email", formData.email);
      form.append("file", formData.file);

      // Upload
      const res = await fetch("/api/upload", {
        method: "POST",
        body: form,
      });

      if (!res.ok) throw new Error("Upload failed");

      setSubmitted(true);
    } catch (err) {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-[300px] flex flex-col gap-4 items-center justify-center">
        <CheckCircle className="w-12 h-12 text-emerald-600" />
        <p className="text-lg font-semibold text-slate-900 dark:text-white">
          Thanks! We’ll reach out soon.
        </p>
      </div>
    );
  }

  return (
    <section className="max-w-2xl mx-auto bg-white dark:bg-gray-900 rounded-2xl shadow-xl p-8 md:p-10 my-20">
      <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-6 text-center">
        Get Your Free Analysis
      </h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-gray-300 mb-2">
            Upload Your Car Contract
          </label>
          <input
            type="file"
            required
            onChange={handleFileChange}
            accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
            className="block w-full text-slate-600 dark:text-gray-200 border border-slate-300 dark:border-gray-700 rounded-lg p-2 bg-white dark:bg-gray-800"
          />
          {fileName && (
            <p className="text-sm text-slate-600 dark:text-gray-300 mt-1">
              {fileName}
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-gray-300 mb-2">
            First Name
          </label>
          <input
            type="text"
            required
            value={formData.firstName}
            onChange={(e) =>
              setFormData({ ...formData, firstName: e.target.value })
            }
            className="w-full px-4 py-3 border border-slate-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-slate-900 dark:text-gray-100"
            placeholder="Enter your first name"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-gray-300 mb-2">
            Email Address
          </label>
          <input
            type="email"
            required
            value={formData.email}
            onChange={(e) =>
              setFormData({ ...formData, email: e.target.value })
            }
            className="w-full px-4 py-3 border border-slate-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-slate-900 dark:text-gray-100"
            placeholder="your@email.com"
          />
        </div>

        {error && <p className="text-red-600 text-sm">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full font-semibold py-4 px-6 rounded-lg transition-colors text-lg shadow-lg text-white bg-[#e08e79] hover:bg-[#d97a62]"
        >
          {loading ? "Uploading..." : "Analyze My Car Contract Free"}
        </button>

        <p className="text-center text-xs text-slate-500 dark:text-gray-400">
          🔒 Files encrypted & auto-deleted after 30 days.
        </p>
      </form>
    </section>
  );
}
