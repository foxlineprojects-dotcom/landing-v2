import BlogPreviewSection from "./BlogPreviewSection";

export default function BlogPreviewWrapper() {
  return <BlogPreviewSection />;
}
